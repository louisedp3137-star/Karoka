Image assets for the site
